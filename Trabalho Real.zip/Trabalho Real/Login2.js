

function verificarIdade() {
    var idadeInput = document.getElementById("idade");
    var idade = parseInt(idadeInput.value);

    var resultadoDiv = document.getElementById("resultado");

    if (idade >= 10) {
      resultadoDiv.innerHTML = "Verificação Feita! Por favor ensira a nova senha!";
      window.location.href = "home.html";
    } else {
      resultadoDiv.innerHTML = "Codigo incorreto!";
    }
  }